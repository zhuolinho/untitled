struct	group { 
	char	*name;
	char	*passwd;
	int	gid;
};
